const dateAt = (daysFromNow, hour, minute = 0) => {
  const date = new Date()
  date.setDate(date.getDate() + daysFromNow)
  date.setHours(hour, minute, 0, 0)
  return date.toISOString()
}

export function createSeedData() {
  const teams = [
    { id: 'team-nova', name: 'Nova Wolves', tag: 'NOVA', game: 'Counter-Strike 2', color: '#8b5cf6', wins: 18, losses: 5, ranking: 1, members: 5 },
    { id: 'team-alpha', name: 'Team Alpha', tag: 'ALPHA', game: 'Counter-Strike 2', color: '#a855f7', wins: 16, losses: 7, ranking: 2, members: 5 },
    { id: 'team-omega', name: 'Team Omega', tag: 'OMG', game: 'Counter-Strike 2', color: '#ef4444', wins: 15, losses: 8, ranking: 3, members: 5 },
    { id: 'team-cyber', name: 'Cyber Warriors', tag: 'CYBER', game: 'Valorant', color: '#06b6d4', wins: 14, losses: 6, ranking: 4, members: 5 },
    { id: 'team-night', name: 'Night Hawks', tag: 'HAWKS', game: 'Valorant', color: '#6366f1', wins: 12, losses: 8, ranking: 5, members: 5 },
    { id: 'team-pixel', name: 'Pixel Squad', tag: 'PIXEL', game: 'League of Legends', color: '#f59e0b', wins: 11, losses: 7, ranking: 6, members: 5 },
    { id: 'team-arcade', name: 'Arcade Legends', tag: 'ARCADE', game: 'League of Legends', color: '#3b82f6', wins: 9, losses: 9, ranking: 7, members: 5 },
    { id: 'team-respawn', name: 'Respawn Team', tag: 'RSP', game: 'Rocket League', color: '#22c55e', wins: 8, losses: 6, ranking: 8, members: 3 },
    { id: 'team-ggeasy', name: 'GG Easy', tag: 'GGEZ', game: 'Rocket League', color: '#ec4899', wins: 7, losses: 7, ranking: 9, members: 3 },
    { id: 'team-infinite', name: 'Infinite Gaming', tag: 'INF', game: 'Counter-Strike 2', color: '#14b8a6', wins: 6, losses: 10, ranking: 10, members: 5 },
    { id: 'team-quantum', name: 'Quantum Five', tag: 'QNTM', game: 'Valorant', color: '#f97316', wins: 6, losses: 8, ranking: 11, members: 5 },
    { id: 'team-vertex', name: 'Vertex Club', tag: 'VTX', game: 'Fortnite', color: '#84cc16', wins: 5, losses: 9, ranking: 12, members: 4 },
  ]

  const players = [
    { id: 'player-user', nickname: 'ShadowByte', name: 'Maksymilian Pawlak', teamId: 'team-nova', role: 'Kapitan', game: 'Counter-Strike 2', rating: 1458, status: 'online' },
    { id: 'player-2', nickname: 'NeonFox', name: 'Julia Mazur', teamId: 'team-nova', role: 'Snajper', game: 'Counter-Strike 2', rating: 1392, status: 'online' },
    { id: 'player-3', nickname: 'Vortex', name: 'Kacper Wójcik', teamId: 'team-nova', role: 'Entry', game: 'Counter-Strike 2', rating: 1367, status: 'offline' },
    { id: 'player-4', nickname: 'ByteRush', name: 'Oliwia Król', teamId: 'team-alpha', role: 'Kapitan', game: 'Counter-Strike 2', rating: 1411, status: 'online' },
    { id: 'player-5', nickname: 'ZeroCool', name: 'Jan Nowak', teamId: 'team-omega', role: 'IGL', game: 'Counter-Strike 2', rating: 1389, status: 'offline' },
    { id: 'player-6', nickname: 'Astra', name: 'Amelia Lis', teamId: 'team-cyber', role: 'Duelist', game: 'Valorant', rating: 1344, status: 'online' },
    { id: 'player-7', nickname: 'Kryptic', name: 'Igor Krawczyk', teamId: 'team-night', role: 'Controller', game: 'Valorant', rating: 1320, status: 'in-game' },
    { id: 'player-8', nickname: 'Luna.exe', name: 'Zofia Dudek', teamId: 'team-pixel', role: 'Mid', game: 'League of Legends', rating: 1298, status: 'online' },
    { id: 'player-9', nickname: 'Rift', name: 'Mikołaj Pawlik', teamId: 'team-arcade', role: 'Jungle', game: 'League of Legends', rating: 1276, status: 'offline' },
    { id: 'player-10', nickname: 'Boosted', name: 'Filip Górski', teamId: 'team-respawn', role: 'Striker', game: 'Rocket League', rating: 1262, status: 'online' },
    { id: 'player-11', nickname: 'Orbit', name: 'Natalia Czarnecka', teamId: 'team-ggeasy', role: 'Defender', game: 'Rocket League', rating: 1228, status: 'in-game' },
    { id: 'player-12', nickname: 'Reboot', name: 'Adam Michalski', teamId: 'team-infinite', role: 'Support', game: 'Counter-Strike 2', rating: 1194, status: 'offline' },
  ]

  const tournaments = [
    {
      id: 'tournament-spring',
      name: 'Spring Masters 2026',
      game: 'Counter-Strike 2',
      mode: 'Drużynowy 5v5',
      format: 'Pojedyncza eliminacja',
      status: 'live',
      maxParticipants: 16,
      participants: ['team-alpha', 'team-omega', 'team-nova', 'team-infinite', 'team-cyber', 'team-night', 'team-pixel', 'team-arcade'],
      startDate: dateAt(0, 18),
      prizePool: 10000,
      organizer: 'Nexus Arena',
      description: 'Największy turniej CS2 tej wiosny. Zagraj o tytuł mistrza i pulę 10 000 PLN.',
      cover: 'violet',
    },
    {
      id: 'tournament-gaming-cup',
      name: 'Gaming Cup #3',
      game: 'Valorant',
      mode: 'Drużynowy 5v5',
      format: 'Podwójna eliminacja',
      status: 'live',
      maxParticipants: 12,
      participants: ['team-cyber', 'team-night', 'team-quantum', 'team-alpha', 'team-nova', 'team-omega'],
      startDate: dateAt(1, 16),
      prizePool: 7500,
      organizer: 'GG League',
      description: 'Trzecia odsłona dynamicznego pucharu Valorant dla ambitnych zespołów.',
      cover: 'cyan',
    },
    {
      id: 'tournament-retro',
      name: 'Retro Games Cup',
      game: 'Rocket League',
      mode: 'Drużynowy 3v3',
      format: 'Faza grupowa + playoff',
      status: 'registration',
      maxParticipants: 8,
      participants: ['team-respawn', 'team-ggeasy', 'team-vertex'],
      startDate: dateAt(5, 17),
      prizePool: 3000,
      organizer: 'Pixel House',
      description: 'Kolorowy turniej z retro oprawą, szybkimi meczami i otwartymi zapisami.',
      cover: 'pink',
    },
    {
      id: 'tournament-rift',
      name: 'Rift Rivals Open',
      game: 'League of Legends',
      mode: 'Drużynowy 5v5',
      format: 'System szwajcarski',
      status: 'registration',
      maxParticipants: 16,
      participants: ['team-pixel', 'team-arcade', 'team-infinite', 'team-quantum'],
      startDate: dateAt(9, 12),
      prizePool: 5000,
      organizer: 'Rift Polska',
      description: 'Otwarty turniej LoL dla drużyn z całej Polski. Sześć rund i playoff dla TOP 8.',
      cover: 'orange',
    },
    {
      id: 'tournament-solo',
      name: 'Solo Royale Night',
      game: 'Fortnite',
      mode: 'Solo',
      format: 'Punkty po 5 mapach',
      status: 'upcoming',
      maxParticipants: 64,
      participants: [],
      startDate: dateAt(14, 20),
      prizePool: 2500,
      organizer: 'Nexus Arena',
      description: 'Wieczorny turniej solo. Liczą się eliminacje, pozycja i konsekwencja.',
      cover: 'green',
    },
    {
      id: 'tournament-winter',
      name: 'Winter Clash',
      game: 'Counter-Strike 2',
      mode: 'Drużynowy 5v5',
      format: 'Pojedyncza eliminacja',
      status: 'finished',
      maxParticipants: 8,
      participants: ['team-alpha', 'team-omega', 'team-nova', 'team-infinite', 'team-cyber', 'team-night', 'team-pixel', 'team-arcade'],
      startDate: dateAt(-20, 18),
      prizePool: 4500,
      organizer: 'Nexus Arena',
      description: 'Zakończona zimowa rywalizacja o pierwszy puchar tego sezonu.',
      cover: 'blue',
      winnerId: 'team-nova',
    },
  ]

  const matches = [
    { id: 'match-1', tournamentId: 'tournament-spring', teamAId: 'team-alpha', teamBId: 'team-omega', date: dateAt(0, 18), stage: 'Półfinał', bestOf: 3, status: 'scheduled', scoreA: null, scoreB: null, stream: true },
    { id: 'match-2', tournamentId: 'tournament-spring', teamAId: 'team-cyber', teamBId: 'team-night', date: dateAt(0, 20), stage: 'Półfinał', bestOf: 3, status: 'scheduled', scoreA: null, scoreB: null, stream: true },
    { id: 'match-3', tournamentId: 'tournament-gaming-cup', teamAId: 'team-pixel', teamBId: 'team-arcade', date: dateAt(1, 16), stage: 'Ćwierćfinał', bestOf: 3, status: 'scheduled', scoreA: null, scoreB: null, stream: false },
    { id: 'match-4', tournamentId: 'tournament-gaming-cup', teamAId: 'team-respawn', teamBId: 'team-ggeasy', date: dateAt(1, 18), stage: 'Ćwierćfinał', bestOf: 3, status: 'scheduled', scoreA: null, scoreB: null, stream: false },
    { id: 'match-5', tournamentId: 'tournament-winter', teamAId: 'team-nova', teamBId: 'team-alpha', date: dateAt(-20, 20), stage: 'Finał', bestOf: 3, status: 'finished', scoreA: 2, scoreB: 1, stream: true },
    { id: 'match-6', tournamentId: 'tournament-winter', teamAId: 'team-omega', teamBId: 'team-infinite', date: dateAt(-21, 18), stage: 'Półfinał', bestOf: 3, status: 'finished', scoreA: 0, scoreB: 2, stream: false },
    { id: 'match-7', tournamentId: 'tournament-spring', teamAId: 'team-nova', teamBId: 'team-infinite', date: dateAt(-1, 19), stage: 'Ćwierćfinał', bestOf: 3, status: 'finished', scoreA: 2, scoreB: 0, stream: true },
  ]

  const activities = [
    { id: 'activity-1', type: 'join', message: 'Team Alpha dołączył do Spring Masters 2026', createdAt: dateAt(0, new Date().getHours() - 1) },
    { id: 'activity-2', type: 'result', message: 'Mecz Nova Wolves vs Infinite Gaming zakończył się wynikiem 2 : 0', createdAt: dateAt(-1, 19) },
    { id: 'activity-3', type: 'team', message: 'Nowa drużyna Quantum Five została zarejestrowana', createdAt: dateAt(-1, 14) },
    { id: 'activity-4', type: 'tournament', message: 'Otwarto zapisy do Retro Games Cup', createdAt: dateAt(-2, 12) },
    { id: 'activity-5', type: 'announcement', message: 'Opublikowano harmonogram transmisji na ten tydzień', createdAt: dateAt(-3, 10) },
  ]

  const announcements = [
    { id: 'announcement-1', title: 'Harmonogram transmisji', body: 'Półfinały Spring Masters pokażemy dziś od 18:00. Dołącz do transmisji w zakładce Transmisje.', type: 'info', publishedAt: dateAt(0, 9), pinned: true },
    { id: 'announcement-2', title: 'Zapisy do Retro Games Cup', body: 'Zostało tylko 5 miejsc. Kapitanowie mogą zgłaszać swoje drużyny do piątku.', type: 'important', publishedAt: dateAt(-1, 12), pinned: false },
    { id: 'announcement-3', title: 'Aktualizacja regulaminu', body: 'Doprecyzowaliśmy zasady zgłaszania zmian w składzie przed rozpoczęciem meczu.', type: 'update', publishedAt: dateAt(-4, 16), pinned: false },
  ]

  const settings = [
    {
      id: 'app',
      profile: { name: 'Maksymilian Pawlak', nickname: 'ShadowByte', role: 'Administrator', email: 'admin@nexus-arena.local' },
      notifications: { matches: true, registrations: true, announcements: false },
      compactMode: false,
      currentTeamId: 'team-nova',
    },
  ]

  return { tournaments, teams, players, matches, activities, announcements, settings }
}
