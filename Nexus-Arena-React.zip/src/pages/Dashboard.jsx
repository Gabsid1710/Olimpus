import { useMemo } from 'react'
import { useNavigate, useOutletContext } from 'react-router-dom'
import {
  ArrowRight,
  CalendarCheck,
  Gamepad2,
  Megaphone,
  Plus,
  Radio,
  Trophy,
  UsersRound,
  WalletCards,
} from 'lucide-react'
import PageHeader from '../components/PageHeader'
import StatCard from '../components/StatCard'
import TeamBadge from '../components/TeamBadge'
import TournamentCover from '../components/TournamentCover'
import { useArena } from '../context/ArenaContext'
import { formatCurrency, formatDateTime, relativeTime, statusLabels } from '../utils/formatters'

const activityIcons = {
  join: UsersRound,
  result: Gamepad2,
  team: UsersRound,
  tournament: Trophy,
  announcement: Megaphone,
}

function MiniChart() {
  return (
    <div className="mini-chart" aria-label="Wykres liczby zapisów w ostatnich 30 dniach">
      <div className="mini-chart__axis"><span>40</span><span>30</span><span>20</span><span>10</span><span>0</span></div>
      <svg viewBox="0 0 600 190" role="img" aria-labelledby="chart-title chart-desc" preserveAspectRatio="none">
        <title id="chart-title">Aktywność turniejowa</title>
        <desc id="chart-desc">Liczba zapisów wahała się między 14 a 37 w ciągu ostatnich 30 dni.</desc>
        <defs>
          <linearGradient id="areaGradient" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity=".55" />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0" />
          </linearGradient>
        </defs>
        <g className="mini-chart__grid">
          <line x1="0" y1="15" x2="600" y2="15" />
          <line x1="0" y1="55" x2="600" y2="55" />
          <line x1="0" y1="95" x2="600" y2="95" />
          <line x1="0" y1="135" x2="600" y2="135" />
          <line x1="0" y1="175" x2="600" y2="175" />
        </g>
        <path className="mini-chart__area" d="M0,78 C35,100 52,52 78,58 S115,132 145,95 S172,15 205,49 S252,90 285,55 S328,42 355,78 S405,55 430,122 S484,128 515,103 S558,57 600,86 L600,190 L0,190 Z" />
        <path className="mini-chart__line" d="M0,78 C35,100 52,52 78,58 S115,132 145,95 S172,15 205,49 S252,90 285,55 S328,42 355,78 S405,55 430,122 S484,128 515,103 S558,57 600,86" />
        {[['0','78'],['78','58'],['145','95'],['205','49'],['285','55'],['355','78'],['430','122'],['515','103'],['600','86']].map(([cx, cy]) => (
          <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r="4" />
        ))}
      </svg>
      <div className="mini-chart__labels"><span>1 lis</span><span>8 lis</span><span>15 lis</span><span>22 lis</span><span>30 lis</span></div>
    </div>
  )
}

export default function Dashboard() {
  const { tournaments, teams, matches, activities } = useArena()
  const { openCreateTournament } = useOutletContext()
  const navigate = useNavigate()

  const upcomingMatches = useMemo(
    () => matches
      .filter((match) => match.status === 'scheduled')
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .slice(0, 4),
    [matches],
  )
  const activeTournaments = tournaments.filter((item) => ['live', 'registration'].includes(item.status)).slice(0, 3)
  const finishedMatches = matches.filter((match) => match.status === 'finished').length
  const prizePool = tournaments.reduce((total, item) => total + item.prizePool, 0)
  const findTeam = (id) => teams.find((team) => team.id === id)
  const findTournament = (id) => tournaments.find((tournament) => tournament.id === id)

  return (
    <div className="page page--dashboard">
      <PageHeader
        eyebrow="Nexus command center"
        title="Witaj z powrotem, ShadowByte!"
        description="Zarządzaj turniejami, drużynami i meczami w jednym miejscu."
        actions={(
          <button className="button button--primary" type="button" onClick={openCreateTournament}>
            <Plus size={18} /> Utwórz turniej
          </button>
        )}
      />

      <section className="stats-grid" aria-label="Podsumowanie">
        <StatCard icon={Trophy} tone="violet" label="Aktywne turnieje" value={activeTournaments.length} detail="Zobacz wszystkie" onClick={() => navigate('/turnieje')} />
        <StatCard icon={UsersRound} tone="blue" label="Zarejestrowane drużyny" value={teams.length} detail="Baza zespołów" onClick={() => navigate('/zespoly')} />
        <StatCard icon={Gamepad2} tone="green" label="Rozegrane mecze" value={finishedMatches + 126} detail="Pełna historia" onClick={() => navigate('/wyniki')} />
        <StatCard icon={WalletCards} tone="amber" label="Łączna pula nagród" value={formatCurrency(prizePool)} detail="Szczegóły rozgrywek" onClick={() => navigate('/turnieje')} />
      </section>

      <div className="dashboard-grid">
        <section className="panel panel--matches">
          <header className="panel__header">
            <div><span className="panel__kicker"><CalendarCheck size={15} /> Terminarz</span><h2>Nadchodzące mecze</h2></div>
            <button className="text-button" type="button" onClick={() => navigate('/mecze')}>Zobacz wszystkie <ArrowRight size={15} /></button>
          </header>
          <div className="match-list">
            {upcomingMatches.map((match) => {
              const tournament = findTournament(match.tournamentId)
              return (
                <article className="match-row" key={match.id}>
                  <TeamBadge team={findTeam(match.teamAId)} compact />
                  <div className="match-row__versus">
                    <time dateTime={match.date}>{formatDateTime(match.date)}</time>
                    <strong>VS</strong>
                    <small>Bo{match.bestOf}</small>
                  </div>
                  <TeamBadge team={findTeam(match.teamBId)} compact align="end" />
                  <div className="match-row__meta"><strong>{match.stage}</strong><small>{tournament?.name}</small></div>
                </article>
              )
            })}
          </div>
        </section>

        <section className="panel panel--tournaments">
          <header className="panel__header">
            <div><span className="panel__kicker"><Trophy size={15} /> Na żywo</span><h2>Aktywne turnieje</h2></div>
            <button className="text-button" type="button" onClick={() => navigate('/turnieje')}>Zobacz wszystkie <ArrowRight size={15} /></button>
          </header>
          <div className="dashboard-tournaments">
            {activeTournaments.map((tournament) => {
              const fill = Math.round((tournament.participants.length / tournament.maxParticipants) * 100)
              return (
                <button className="dashboard-tournament" key={tournament.id} type="button" onClick={() => navigate(`/turnieje?open=${tournament.id}`)}>
                  <TournamentCover tournament={tournament} size="small" />
                  <span className="dashboard-tournament__body">
                    <span className="dashboard-tournament__title"><strong>{tournament.name}</strong><span className={`status status--${tournament.status}`}><i />{statusLabels[tournament.status]}</span></span>
                    <span className="progress"><i style={{ width: `${fill}%` }} /></span>
                    <small>{tournament.format}</small>
                  </span>
                  <span className="dashboard-tournament__count"><strong>{tournament.participants.length}</strong><small>/{tournament.maxParticipants}</small></span>
                </button>
              )
            })}
          </div>
        </section>

        <section className="panel panel--activity">
          <header className="panel__header">
            <div><span className="panel__kicker"><Radio size={15} /> Aktualizacje</span><h2>Ostatnie aktywności</h2></div>
          </header>
          <div className="activity-list">
            {[...activities].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 4).map((activity) => {
              const Icon = activityIcons[activity.type] ?? Gamepad2
              return (
                <article className="activity-row" key={activity.id}>
                  <span className={`activity-row__icon activity-row__icon--${activity.type}`}><Icon size={17} /></span>
                  <span><strong>{activity.message}</strong><time dateTime={activity.createdAt}>{relativeTime(activity.createdAt)}</time></span>
                </article>
              )
            })}
          </div>
        </section>

        <section className="panel panel--chart">
          <header className="panel__header">
            <div><span className="panel__kicker"><UsersRound size={15} /> Ostatnie 30 dni</span><h2>Aktywność turniejowa</h2></div>
            <select className="select select--compact" aria-label="Zakres wykresu" defaultValue="30"><option value="30">30 dni</option><option value="7">7 dni</option><option value="90">90 dni</option></select>
          </header>
          <MiniChart />
        </section>
      </div>
    </div>
  )
}
