import { useState } from 'react'
import { CalendarDays, CheckCircle2, Clock3, Edit3, Gamepad2, Radio, Search, Swords } from 'lucide-react'
import Modal from '../components/Modal'
import PageHeader from '../components/PageHeader'
import TeamBadge from '../components/TeamBadge'
import { useArena } from '../context/ArenaContext'
import { formatDateTime } from '../utils/formatters'

function ResultModal({ match, teams, onClose, onSave }) {
  const [scoreA, setScoreA] = useState(match?.scoreA ?? 0)
  const [scoreB, setScoreB] = useState(match?.scoreB ?? 0)
  if (!match) return null
  const teamA = teams.find((team) => team.id === match.teamAId)
  const teamB = teams.find((team) => team.id === match.teamBId)
  const submit = async (event) => {
    event.preventDefault()
    if (Number(scoreA) === Number(scoreB)) return
    await onSave(match.id, scoreA, scoreB)
    onClose()
  }
  return (
    <Modal open={Boolean(match)} onClose={onClose} title="Wpisz wynik" eyebrow={`${match.stage} • BO${match.bestOf}`}>
      <form className="score-form" onSubmit={submit}>
        <div><TeamBadge team={teamA} /><input type="number" min="0" max={match.bestOf} value={scoreA} onChange={(event) => setScoreA(event.target.value)} aria-label={`Wynik ${teamA?.name}`} /></div>
        <span>:</span>
        <div><TeamBadge team={teamB} align="end" /><input type="number" min="0" max={match.bestOf} value={scoreB} onChange={(event) => setScoreB(event.target.value)} aria-label={`Wynik ${teamB?.name}`} /></div>
        {Number(scoreA) === Number(scoreB) && <p className="form-error">Mecz nie może zakończyć się remisem.</p>}
        <div className="modal__actions"><button className="button button--ghost" type="button" onClick={onClose}>Anuluj</button><button className="button button--primary" type="submit">Zapisz wynik</button></div>
      </form>
    </Modal>
  )
}

export default function Matches() {
  const { matches, teams, tournaments, updateMatch } = useArena()
  const [tab, setTab] = useState('scheduled')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const findTeam = (id) => teams.find((team) => team.id === id)
  const findTournament = (id) => tournaments.find((tournament) => tournament.id === id)
  const filtered = matches.filter((match) => {
    const teamA = findTeam(match.teamAId)?.name ?? ''
    const teamB = findTeam(match.teamBId)?.name ?? ''
    const tournament = findTournament(match.tournamentId)?.name ?? ''
    return match.status === tab && `${teamA} ${teamB} ${tournament}`.toLocaleLowerCase('pl').includes(search.toLocaleLowerCase('pl'))
  }).sort((a, b) => tab === 'scheduled' ? new Date(a.date) - new Date(b.date) : new Date(b.date) - new Date(a.date))

  const saveResult = async (id, scoreA, scoreB) => {
    try { await updateMatch(id, scoreA, scoreB) } catch { /* toast */ }
  }

  return (
    <div className="page">
      <PageHeader eyebrow="Harmonogram" title="Mecze" description="Zarządzaj terminarzem, wpisuj wyniki i sprawdzaj transmisje spotkań." />
      <section className="match-summary">
        <div><span className="summary-icon summary-icon--blue"><Clock3 /></span><span><small>Zaplanowane</small><strong>{matches.filter((item) => item.status === 'scheduled').length}</strong></span></div>
        <div><span className="summary-icon summary-icon--green"><CheckCircle2 /></span><span><small>Zakończone</small><strong>{matches.filter((item) => item.status === 'finished').length}</strong></span></div>
        <div><span className="summary-icon summary-icon--violet"><Radio /></span><span><small>Z transmisją</small><strong>{matches.filter((item) => item.stream).length}</strong></span></div>
      </section>
      <section className="toolbar"><label className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Szukaj drużyny lub turnieju…" aria-label="Szukaj meczu" /></label></section>
      <div className="filter-tabs" role="tablist"><button className={tab === 'scheduled' ? 'active' : ''} type="button" onClick={() => setTab('scheduled')}>Nadchodzące <span>{matches.filter((item) => item.status === 'scheduled').length}</span></button><button className={tab === 'finished' ? 'active' : ''} type="button" onClick={() => setTab('finished')}>Zakończone <span>{matches.filter((item) => item.status === 'finished').length}</span></button></div>

      <section className="match-cards">
        {filtered.map((match) => {
          const teamA = findTeam(match.teamAId)
          const teamB = findTeam(match.teamBId)
          const tournament = findTournament(match.tournamentId)
          return <article className="match-card" key={match.id}><header><span><Gamepad2 size={15} /> {tournament?.name}</span><strong>{match.stage} • BO{match.bestOf}</strong></header><div className="match-card__arena"><TeamBadge team={teamA} align="end" /><div className="match-card__score">{match.status === 'finished' ? <><strong className={match.scoreA > match.scoreB ? 'winner-score' : ''}>{match.scoreA}</strong><span>:</span><strong className={match.scoreB > match.scoreA ? 'winner-score' : ''}>{match.scoreB}</strong></> : <><strong>VS</strong><small>{formatDateTime(match.date)}</small></>}</div><TeamBadge team={teamB} /></div><footer><span><CalendarDays size={15} /> {formatDateTime(match.date)}</span><span>{match.stream && <><Radio size={15} /> Transmisja</>}</span>{match.status === 'scheduled' && <button className="button button--soft button--small" type="button" onClick={() => setSelected(match)}><Edit3 size={15} /> Wpisz wynik</button>}{match.status === 'finished' && <span className="completed-label"><Swords size={15} /> Zakończony</span>}</footer></article>
        })}
        {!filtered.length && <div className="empty-state"><Gamepad2 size={30} /><h3>Brak meczów</h3><p>Nie ma spotkań pasujących do wybranych kryteriów.</p></div>}
      </section>
      <ResultModal key={selected?.id ?? 'none'} match={selected} teams={teams} onClose={() => setSelected(null)} onSave={saveResult} />
    </div>
  )
}
