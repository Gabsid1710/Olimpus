import { useMemo, useState } from 'react'
import { Gamepad2, Plus, Search, Shield, Sparkles, Swords, Trophy, UsersRound } from 'lucide-react'
import Avatar from '../components/Avatar'
import EmptyState from '../components/EmptyState'
import Modal from '../components/Modal'
import PageHeader from '../components/PageHeader'
import { useArena } from '../context/ArenaContext'

const initialTeam = { name: '', tag: '', game: 'Counter-Strike 2', members: 5, color: '#8b5cf6' }

function CreateTeamModal({ open, onClose }) {
  const { createTeam } = useArena()
  const [form, setForm] = useState(initialTeam)
  const [submitting, setSubmitting] = useState(false)

  const submit = async (event) => {
    event.preventDefault()
    setSubmitting(true)
    try {
      await createTeam(form)
      setForm(initialTeam)
      onClose()
    } catch {
      // Błąd obsługuje globalny toast.
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Dodaj drużynę" eyebrow="Rejestracja zespołu">
      <form className="form-grid" onSubmit={submit}>
        <label className="field form-grid__full"><span>Nazwa drużyny</span><input required minLength="3" maxLength="40" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="np. Neon Raiders" /></label>
        <label className="field"><span>Skrót / tag</span><input required minLength="2" maxLength="6" value={form.tag} onChange={(event) => setForm({ ...form, tag: event.target.value })} placeholder="NRS" /></label>
        <label className="field"><span>Liczba graczy</span><input type="number" min="1" max="10" value={form.members} onChange={(event) => setForm({ ...form, members: event.target.value })} /></label>
        <label className="field form-grid__full"><span>Główna gra</span><select value={form.game} onChange={(event) => setForm({ ...form, game: event.target.value })}><option>Counter-Strike 2</option><option>Valorant</option><option>League of Legends</option><option>Rocket League</option><option>Fortnite</option></select></label>
        <label className="field form-grid__full"><span>Kolor drużyny</span><div className="color-field"><input type="color" value={form.color} onChange={(event) => setForm({ ...form, color: event.target.value })} /><code>{form.color}</code></div></label>
        <div className="modal__actions form-grid__full"><button className="button button--ghost" type="button" onClick={onClose}>Anuluj</button><button className="button button--primary" disabled={submitting}>{submitting ? 'Dodawanie…' : 'Dodaj drużynę'}</button></div>
      </form>
    </Modal>
  )
}

export default function Teams() {
  const { teams, players, tournaments, settings } = useArena()
  const [search, setSearch] = useState('')
  const [game, setGame] = useState('all')
  const [createOpen, setCreateOpen] = useState(false)
  const [selected, setSelected] = useState(null)
  const appSettings = settings.find((item) => item.id === 'app')
  const currentTeam = teams.find((team) => team.id === appSettings?.currentTeamId)
  const games = [...new Set(teams.map((team) => team.game))]
  const filtered = useMemo(() => teams.filter((team) => {
    const query = search.toLocaleLowerCase('pl')
    return (game === 'all' || team.game === game) && (!query || `${team.name} ${team.tag}`.toLocaleLowerCase('pl').includes(query))
  }).sort((a, b) => a.ranking - b.ranking), [game, search, teams])

  const selectedPlayers = selected ? players.filter((player) => player.teamId === selected.id) : []
  const selectedTournaments = selected ? tournaments.filter((tournament) => tournament.participants.includes(selected.id)) : []

  return (
    <div className="page">
      <PageHeader eyebrow="Społeczność" title="Zespoły" description="Przeglądaj drużyny, ich składy oraz pozycję w rankingu." actions={<button className="button button--primary" type="button" onClick={() => setCreateOpen(true)}><Plus size={18} /> Dodaj drużynę</button>} />

      {currentTeam && (
        <section className="team-hero">
          <div className="team-hero__glow" style={{ '--team-color': currentTeam.color }} />
          <Avatar name={currentTeam.tag} color={currentTeam.color} size="xlarge" />
          <div><span className="eyebrow"><Sparkles size={13} /> Twoja drużyna</span><h2>{currentTeam.name}</h2><p>{currentTeam.game} • {currentTeam.members} graczy</p></div>
          <div className="team-hero__stats"><span><small>Ranking</small><strong>#{currentTeam.ranking}</strong></span><span><small>Bilans</small><strong>{currentTeam.wins}–{currentTeam.losses}</strong></span><span><small>Win rate</small><strong>{Math.round((currentTeam.wins / (currentTeam.wins + currentTeam.losses)) * 100)}%</strong></span></div>
        </section>
      )}

      <section className="toolbar">
        <label className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Szukaj zespołu lub tagu…" aria-label="Szukaj zespołu" /></label>
        <label className="select-field"><Gamepad2 size={17} /><select value={game} onChange={(event) => setGame(event.target.value)} aria-label="Filtruj według gry"><option value="all">Wszystkie gry</option>{games.map((item) => <option key={item}>{item}</option>)}</select></label>
      </section>

      {filtered.length ? (
        <section className="team-grid" aria-label="Lista zespołów">
          {filtered.map((team) => {
            const total = team.wins + team.losses || 1
            return (
              <button type="button" className="team-card" key={team.id} onClick={() => setSelected(team)}>
                <div className="team-card__rank">#{team.ranking}</div>
                <Avatar name={team.tag} color={team.color} size="large" />
                <div className="team-card__identity"><h2>{team.name}</h2><span>{team.tag} • {team.game}</span></div>
                <div className="team-card__numbers"><span><Trophy size={16} /><strong>{team.wins}</strong><small>wygranych</small></span><span><Swords size={16} /><strong>{team.losses}</strong><small>porażek</small></span><span><UsersRound size={16} /><strong>{team.members}</strong><small>graczy</small></span></div>
                <div className="team-card__rate"><span><small>Skuteczność</small><strong>{Math.round((team.wins / total) * 100)}%</strong></span><span className="progress"><i style={{ width: `${(team.wins / total) * 100}%`, background: team.color }} /></span></div>
              </button>
            )
          })}
        </section>
      ) : <EmptyState title="Brak zespołów" description="Nie znaleziono drużyn pasujących do filtrów." />}

      <CreateTeamModal open={createOpen} onClose={() => setCreateOpen(false)} />
      <Modal open={Boolean(selected)} onClose={() => setSelected(null)} title={selected?.name ?? ''} eyebrow={selected ? `${selected.tag} • #${selected.ranking} ranking` : ''}>
        {selected && <div className="team-detail"><div className="team-detail__header"><Avatar name={selected.tag} color={selected.color} size="xlarge" /><div><h3>{selected.name}</h3><p><Gamepad2 size={15} /> {selected.game}</p></div><span className="record"><strong>{selected.wins}:{selected.losses}</strong><small>bilans</small></span></div><section><h3>Skład</h3>{selectedPlayers.length ? <div className="roster-list">{selectedPlayers.map((player) => <div key={player.id}><Avatar name={player.nickname} color={selected.color} size="small" status={player.status} /><span><strong>{player.nickname}</strong><small>{player.role}</small></span><b>{player.rating}</b></div>)}</div> : <p className="muted">Skład nie został jeszcze uzupełniony.</p>}</section><section><h3>Rozgrywki</h3><div className="tag-list">{selectedTournaments.length ? selectedTournaments.map((tournament) => <span key={tournament.id}><Shield size={14} /> {tournament.name}</span>) : <span>Brak aktywnych zgłoszeń</span>}</div></section></div>}
      </Modal>
    </div>
  )
}
