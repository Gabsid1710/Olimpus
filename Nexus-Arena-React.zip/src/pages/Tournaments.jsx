import { useMemo, useState } from 'react'
import { useOutletContext, useSearchParams } from 'react-router-dom'
import {
  CalendarDays,
  ChevronRight,
  Clock3,
  Coins,
  Filter,
  Gamepad2,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  Trophy,
  UsersRound,
} from 'lucide-react'
import EmptyState from '../components/EmptyState'
import Modal from '../components/Modal'
import PageHeader from '../components/PageHeader'
import TeamBadge from '../components/TeamBadge'
import TournamentCover from '../components/TournamentCover'
import { useArena } from '../context/ArenaContext'
import { formatCurrency, formatDate, statusLabels } from '../utils/formatters'

const filterOptions = [
  { value: 'all', label: 'Wszystkie' },
  { value: 'live', label: 'Trwające' },
  { value: 'registration', label: 'Zapisy' },
  { value: 'upcoming', label: 'Nadchodzące' },
  { value: 'finished', label: 'Zakończone' },
]

function TournamentDetails({ tournament, teams, currentParticipantId, onClose, onToggle, onDelete }) {
  if (!tournament) return null
  const registered = tournament.participants.includes(currentParticipantId)
  const canJoin = tournament.status === 'registration'
  const participantTeams = teams.filter((team) => tournament.participants.includes(team.id))
  const occupancy = Math.round((tournament.participants.length / tournament.maxParticipants) * 100)

  return (
    <Modal open={Boolean(tournament)} onClose={onClose} title={tournament.name} eyebrow={`${tournament.game} • ${statusLabels[tournament.status]}`} size="large">
      <div className="tournament-detail">
        <TournamentCover tournament={tournament} size="hero" />
        <div className="tournament-detail__summary">
          <span className={`status status--${tournament.status}`}><i />{statusLabels[tournament.status]}</span>
          <p>{tournament.description || 'Turniej społeczności Nexus Arena.'}</p>
          <div className="detail-stats">
            <div><CalendarDays /><span><small>Start</small><strong>{formatDate(tournament.startDate, { hour: '2-digit', minute: '2-digit' })}</strong></span></div>
            <div><UsersRound /><span><small>Uczestnicy</small><strong>{tournament.participants.length} / {tournament.maxParticipants}</strong></span></div>
            <div><Coins /><span><small>Pula nagród</small><strong>{formatCurrency(tournament.prizePool)}</strong></span></div>
            <div><Trophy /><span><small>Format</small><strong>{tournament.format}</strong></span></div>
          </div>
        </div>

        <section className="tournament-detail__participants">
          <header>
            <div><span className="eyebrow">Zapełnienie {occupancy}%</span><h3>Zgłoszeni uczestnicy</h3></div>
            <span className="progress progress--wide"><i style={{ width: `${occupancy}%` }} /></span>
          </header>
          {participantTeams.length > 0 ? (
            <div className="participant-grid">
              {participantTeams.map((team) => <TeamBadge team={team} key={team.id} />)}
              {tournament.mode === 'Solo' && tournament.participants.includes('player-user') && (
                <div className="solo-participant"><span>SB</span><strong>ShadowByte</strong></div>
              )}
            </div>
          ) : (
            <p className="muted">Lista uczestników jest jeszcze pusta.</p>
          )}
        </section>

        <div className="modal__actions tournament-detail__actions">
          <button className="button button--danger-ghost" type="button" onClick={() => onDelete(tournament)}><Trash2 size={17} /> Usuń turniej</button>
          <span className="flex-spacer" />
          <button className="button button--ghost" type="button" onClick={onClose}>Zamknij</button>
          {canJoin && (
            <button className={`button ${registered ? 'button--soft' : 'button--primary'}`} type="button" onClick={() => onToggle(tournament.id)}>
              {registered ? 'Wycofaj zgłoszenie' : 'Dołącz do turnieju'}
            </button>
          )}
        </div>
      </div>
    </Modal>
  )
}

export default function Tournaments() {
  const { tournaments, teams, settings, toggleTournamentRegistration, deleteTournament } = useArena()
  const { openCreateTournament } = useOutletContext()
  const [searchParams, setSearchParams] = useSearchParams()
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [game, setGame] = useState('all')
  const selectedId = searchParams.get('open')
  const selected = tournaments.find((item) => item.id === selectedId)
  const appSettings = settings.find((item) => item.id === 'app')
  const currentTeamId = appSettings?.currentTeamId

  const games = useMemo(() => [...new Set(tournaments.map((item) => item.game))].sort(), [tournaments])
  const filtered = useMemo(() => {
    const normalized = search.trim().toLocaleLowerCase('pl')
    return [...tournaments]
      .filter((item) => filter === 'all' || item.status === filter)
      .filter((item) => game === 'all' || item.game === game)
      .filter((item) => !normalized || `${item.name} ${item.game} ${item.organizer}`.toLocaleLowerCase('pl').includes(normalized))
      .sort((a, b) => {
        const statusOrder = { live: 0, registration: 1, upcoming: 2, finished: 3 }
        return statusOrder[a.status] - statusOrder[b.status] || new Date(a.startDate) - new Date(b.startDate)
      })
  }, [filter, game, search, tournaments])

  const openDetails = (id) => {
    setSearchParams({ open: id })
  }

  const closeDetails = () => {
    setSearchParams({})
  }

  const handleDelete = async (tournament) => {
    const confirmed = window.confirm(`Czy na pewno usunąć turniej „${tournament.name}” i powiązane mecze?`)
    if (!confirmed) return
    closeDetails()
    await deleteTournament(tournament.id)
  }

  const handleToggle = async (id) => {
    try {
      await toggleTournamentRegistration(id)
    } catch {
      // Komunikat błędu jest wyświetlany globalnie.
    }
  }

  return (
    <div className="page">
      <PageHeader
        eyebrow="Centrum rozgrywek"
        title="Turnieje"
        description="Przeglądaj otwarte wydarzenia, zapisuj drużynę i zarządzaj własnymi turniejami."
        actions={<button className="button button--primary" type="button" onClick={openCreateTournament}><Plus size={18} /> Nowy turniej</button>}
      />

      <section className="toolbar" aria-label="Filtry turniejów">
        <label className="search-field">
          <Search size={18} />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Szukaj po nazwie, grze lub organizatorze…" aria-label="Szukaj turnieju" />
          {search && <button type="button" onClick={() => setSearch('')} aria-label="Wyczyść wyszukiwanie">×</button>}
        </label>
        <label className="select-field"><Filter size={17} /><select value={game} onChange={(event) => setGame(event.target.value)} aria-label="Filtruj po grze"><option value="all">Wszystkie gry</option>{games.map((item) => <option key={item}>{item}</option>)}</select></label>
      </section>

      <div className="filter-tabs" role="tablist" aria-label="Status turnieju">
        {filterOptions.map((option) => (
          <button key={option.value} className={filter === option.value ? 'active' : ''} type="button" onClick={() => setFilter(option.value)}>
            {option.label}
            <span>{option.value === 'all' ? tournaments.length : tournaments.filter((item) => item.status === option.value).length}</span>
          </button>
        ))}
      </div>

      {filtered.length > 0 ? (
        <section className="tournament-grid" aria-label="Lista turniejów">
          {filtered.map((tournament) => {
            const participantId = tournament.mode === 'Solo' ? 'player-user' : currentTeamId
            const registered = tournament.participants.includes(participantId)
            const occupancy = Math.round((tournament.participants.length / tournament.maxParticipants) * 100)
            return (
              <article className="tournament-card" key={tournament.id}>
                <button className="tournament-card__cover-button" type="button" onClick={() => openDetails(tournament.id)} aria-label={`Szczegóły: ${tournament.name}`}>
                  <TournamentCover tournament={tournament} size="card" />
                  <span className={`status status--${tournament.status}`}><i />{statusLabels[tournament.status]}</span>
                </button>
                <div className="tournament-card__body">
                  <div className="tournament-card__title">
                    <span><small>{tournament.game}</small><h2>{tournament.name}</h2></span>
                    <Gamepad2 size={19} />
                  </div>
                  <div className="tournament-card__meta">
                    <span><CalendarDays size={15} /> {formatDate(tournament.startDate)}</span>
                    <span><UsersRound size={15} /> {tournament.mode}</span>
                    <span><Coins size={15} /> {formatCurrency(tournament.prizePool)}</span>
                  </div>
                  <div className="tournament-card__capacity">
                    <span><small>Zapisani</small><strong>{tournament.participants.length}/{tournament.maxParticipants}</strong></span>
                    <span className="progress"><i style={{ width: `${occupancy}%` }} /></span>
                  </div>
                  <div className="tournament-card__footer">
                    <span><ShieldCheck size={15} /> {tournament.organizer}</span>
                    <button className="text-button" type="button" onClick={() => openDetails(tournament.id)}>Szczegóły <ChevronRight size={15} /></button>
                  </div>
                  {tournament.status === 'registration' && (
                    <button className={`button button--block ${registered ? 'button--soft' : 'button--primary'}`} type="button" onClick={() => handleToggle(tournament.id)}>
                      {registered ? 'Zgłoszono • wycofaj' : 'Dołącz do turnieju'}
                    </button>
                  )}
                  {tournament.status === 'upcoming' && <div className="card-note"><Clock3 size={15} /> Zapisy ruszą wkrótce</div>}
                </div>
              </article>
            )
          })}
        </section>
      ) : (
        <EmptyState title="Nie znaleźliśmy turniejów" description="Zmień filtry lub utwórz nowe wydarzenie." action={<button className="button button--primary" type="button" onClick={openCreateTournament}><Plus size={17} /> Utwórz turniej</button>} />
      )}

      <TournamentDetails
        tournament={selected}
        teams={teams}
        currentParticipantId={selected?.mode === 'Solo' ? 'player-user' : currentTeamId}
        onClose={closeDetails}
        onToggle={handleToggle}
        onDelete={handleDelete}
      />
    </div>
  )
}
