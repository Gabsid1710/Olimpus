import { useState } from 'react'
import { CalendarDays, Eye, MessageCircle, Play, Radio, Send, Signal, Volume2 } from 'lucide-react'
import Avatar from '../components/Avatar'
import PageHeader from '../components/PageHeader'
import TeamBadge from '../components/TeamBadge'
import { useArena } from '../context/ArenaContext'
import { formatDateTime } from '../utils/formatters'

const initialChat = [
  { id: 1, user: 'NeonFox', text: 'Ale akcja! 🔥', color: '#a855f7' },
  { id: 2, user: 'Kryptic', text: 'Nova wygląda dziś bardzo mocno.', color: '#06b6d4' },
  { id: 3, user: 'Luna.exe', text: 'GG, czekam na kolejną mapę', color: '#ec4899' },
]

export default function Streams() {
  const { matches, teams, tournaments, notify } = useArena()
  const [playing, setPlaying] = useState(false)
  const [chat, setChat] = useState(initialChat)
  const [message, setMessage] = useState('')
  const streamed = matches.filter((match) => match.stream)
  const featured = streamed.find((match) => match.status === 'scheduled') ?? streamed[0]
  const teamA = teams.find((team) => team.id === featured?.teamAId)
  const teamB = teams.find((team) => team.id === featured?.teamBId)
  const tournament = tournaments.find((item) => item.id === featured?.tournamentId)

  const sendMessage = (event) => {
    event.preventDefault()
    if (!message.trim()) return
    setChat((current) => [...current, { id: Date.now(), user: 'ShadowByte', text: message.trim(), color: '#8b5cf6' }])
    setMessage('')
  }

  return (
    <div className="page">
      <PageHeader eyebrow="Nexus Live" title="Transmisje" description="Oglądaj najważniejsze spotkania i rozmawiaj ze społecznością na żywo." />
      <section className="stream-layout">
        <div className="stream-main">
          <div className={`video-stage ${playing ? 'video-stage--playing' : ''}`}>
            <div className="video-stage__ambient" />
            <span className="live-pill"><i /> NA ŻYWO</span>
            <span className="viewer-pill"><Eye size={14} /> 1 284</span>
            <div className="video-stage__versus"><div><Avatar name={teamA?.tag ?? 'A'} color={teamA?.color} size="xlarge" /><strong>{teamA?.name}</strong></div><span><small>{tournament?.name}</small><b>VS</b><em>{featured?.stage}</em></span><div><Avatar name={teamB?.tag ?? 'B'} color={teamB?.color} size="xlarge" /><strong>{teamB?.name}</strong></div></div>
            {!playing && <button className="video-stage__play" type="button" aria-label="Uruchom transmisję" onClick={() => { setPlaying(true); notify('Uruchomiono demonstracyjny odtwarzacz transmisji.') }}><Play fill="currentColor" /></button>}
            {playing && <div className="video-stage__signal"><Signal /><span>Sygnał demonstracyjny</span></div>}
            <div className="video-controls"><button type="button" aria-label={playing ? 'Pauza' : 'Odtwórz'} onClick={() => setPlaying((value) => !value)}><Play size={17} fill="currentColor" /></button><Volume2 size={17} /><span className="video-controls__timeline"><i /></span><strong>LIVE</strong><Radio size={17} /></div>
          </div>
          <div className="stream-info"><div><span className="status status--live"><i />Transmisja oficjalna</span><h2>{teamA?.name} vs {teamB?.name}</h2><p>{tournament?.name} • {featured?.stage} • BO{featured?.bestOf}</p></div><button className="button button--soft" type="button" onClick={() => notify('Link do transmisji skopiowany do schowka (demo).')}>Udostępnij</button></div>
        </div>
        <aside className="stream-chat"><header><div><MessageCircle size={18} /><strong>Czat na żywo</strong></div><span>428 online</span></header><div className="chat-messages">{chat.map((item) => <div className="chat-message" key={item.id}><Avatar name={item.user} color={item.color} size="tiny" /><p><strong style={{ color: item.color }}>{item.user}</strong> {item.text}</p></div>)}</div><form onSubmit={sendMessage}><input value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Napisz wiadomość…" aria-label="Wiadomość na czacie" maxLength="120" /><button type="submit" aria-label="Wyślij"><Send size={17} /></button></form></aside>
      </section>

      <section className="panel stream-schedule"><header className="panel__header"><div><span className="panel__kicker"><CalendarDays size={15} /> Program</span><h2>Następne transmisje</h2></div></header><div className="stream-list">{streamed.map((match) => { const left = teams.find((team) => team.id === match.teamAId); const right = teams.find((team) => team.id === match.teamBId); return <article key={match.id}><time dateTime={match.date}><strong>{formatDateTime(match.date)}</strong><small>{match.status === 'finished' ? 'Powtórka' : 'Premiera'}</small></time><TeamBadge team={left} compact align="end" /><span>VS</span><TeamBadge team={right} compact /><span className={`status status--${match.status === 'finished' ? 'finished' : 'registration'}`}><i />{match.status === 'finished' ? 'VOD' : 'Zaplanowana'}</span></article> })}</div></section>
    </div>
  )
}
