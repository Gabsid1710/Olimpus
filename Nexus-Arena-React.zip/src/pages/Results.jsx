import { Award, Crown, Medal, Swords, TrendingUp, Trophy } from 'lucide-react'
import Avatar from '../components/Avatar'
import PageHeader from '../components/PageHeader'
import TeamBadge from '../components/TeamBadge'
import { useArena } from '../context/ArenaContext'
import { formatDateTime } from '../utils/formatters'

export default function Results() {
  const { matches, teams, tournaments } = useArena()
  const finished = matches.filter((match) => match.status === 'finished').sort((a, b) => new Date(b.date) - new Date(a.date))
  const ranking = [...teams].sort((a, b) => a.ranking - b.ranking)
  const findTeam = (id) => teams.find((team) => team.id === id)
  const findTournament = (id) => tournaments.find((tournament) => tournament.id === id)
  const podium = ranking.slice(0, 3)

  return (
    <div className="page">
      <PageHeader eyebrow="Klasyfikacja" title="Wyniki i ranking" description="Sprawdzaj rezultaty meczów, formę zespołów i aktualną tabelę sezonu." />
      <section className="podium" aria-label="Najlepsze drużyny">
        {[podium[1], podium[0], podium[2]].map((team, visualIndex) => {
          if (!team) return null
          const position = [2, 1, 3][visualIndex]
          return <article className={`podium-card podium-card--${position}`} key={team.id}><span className="podium-card__place">{position === 1 ? <Crown /> : <Medal />}</span><Avatar name={team.tag} color={team.color} size="xlarge" /><h2>{team.name}</h2><p>{team.game}</p><div><span><strong>{team.wins}</strong><small>W</small></span><span><strong>{team.losses}</strong><small>P</small></span><span><strong>{Math.round((team.wins / (team.wins + team.losses)) * 100)}%</strong><small>WR</small></span></div></article>
        })}
      </section>
      <div className="results-layout">
        <section className="panel ranking-panel"><header className="panel__header"><div><span className="panel__kicker"><TrendingUp size={15} /> Sezon 2026</span><h2>Ranking drużyn</h2></div></header><div className="ranking-list">{ranking.map((team, index) => <div key={team.id} className={index < 3 ? 'ranking-row ranking-row--top' : 'ranking-row'}><span className="ranking-row__position">{index + 1}</span><TeamBadge team={team} compact /><span className="ranking-row__form"><i className="win">W</i><i className="win">W</i><i className={index % 2 ? 'loss' : 'win'}>{index % 2 ? 'P' : 'W'}</i></span><span><strong>{team.wins * 3}</strong><small>pkt</small></span></div>)}</div></section>
        <section className="panel recent-results"><header className="panel__header"><div><span className="panel__kicker"><Swords size={15} /> Historia</span><h2>Ostatnie wyniki</h2></div></header><div>{finished.map((match) => { const teamA = findTeam(match.teamAId); const teamB = findTeam(match.teamBId); return <article key={match.id}><header><span>{findTournament(match.tournamentId)?.name}</span><small>{formatDateTime(match.date)}</small></header><div><TeamBadge team={teamA} compact align="end" /><span className="result-score"><strong className={match.scoreA > match.scoreB ? 'winner-score' : ''}>{match.scoreA}</strong><i>:</i><strong className={match.scoreB > match.scoreA ? 'winner-score' : ''}>{match.scoreB}</strong></span><TeamBadge team={teamB} compact /></div><footer><Award size={14} /> {match.stage} • BO{match.bestOf}</footer></article> })}</div></section>
      </div>
      <section className="season-note"><span><Trophy /></span><div><strong>Sezon trwa</strong><p>Ranking aktualizuje się po każdym zapisanym wyniku. Zwycięstwo daje 3 punkty.</p></div></section>
    </div>
  )
}
