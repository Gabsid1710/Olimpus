import { useState } from 'react'
import { Brackets, ChevronRight, GitFork, RotateCcw, Trophy } from 'lucide-react'
import Avatar from '../components/Avatar'
import PageHeader from '../components/PageHeader'
import { useArena } from '../context/ArenaContext'

function BracketTeam({ team, score, winner }) {
  return (
    <div className={`bracket-team ${winner ? 'bracket-team--winner' : ''}`}>
      {team ? <><Avatar name={team.tag} color={team.color} size="tiny" /><span>{team.name}</span></> : <><span className="bracket-team__tbd">?</span><span>Do ustalenia</span></>}
      <strong>{score ?? '—'}</strong>
    </div>
  )
}

function BracketMatch({ match, teams, label }) {
  const teamA = teams.find((team) => team.id === match?.teamAId)
  const teamB = teams.find((team) => team.id === match?.teamBId)
  const finished = match?.status === 'finished'
  return (
    <article className="bracket-match">
      <header><span>{label}</span>{match?.bestOf && <small>BO{match.bestOf}</small>}</header>
      <BracketTeam team={teamA} score={match?.scoreA} winner={finished && match.scoreA > match.scoreB} />
      <BracketTeam team={teamB} score={match?.scoreB} winner={finished && match.scoreB > match.scoreA} />
    </article>
  )
}

function createVirtualMatches(participants, tournamentId) {
  const output = []
  for (let index = 0; index < Math.min(participants.length, 8); index += 2) {
    output.push({ id: `virtual-${index}`, tournamentId, teamAId: participants[index], teamBId: participants[index + 1], bestOf: 3 })
  }
  return output
}

export default function BracketsPage() {
  const { tournaments, teams, matches, generateBracket } = useArena()
  const eligible = tournaments.filter((tournament) => tournament.mode !== 'Solo')
  const [selectedId, setSelectedId] = useState(eligible.find((item) => item.status === 'live')?.id ?? eligible[0]?.id ?? '')
  const tournament = eligible.find((item) => item.id === selectedId)
  const tournamentMatches = matches.filter((match) => match.tournamentId === selectedId)

  let rounds = { first: [], semi: [], final: [] }
  if (tournament) {
    const existingFirst = tournamentMatches.filter((match) => ['1/8 finału', 'Ćwierćfinał'].includes(match.stage))
    const first = existingFirst.length >= 2 ? existingFirst : createVirtualMatches(tournament.participants, tournament.id)
    rounds = {
      first: first.slice(0, 4),
      semi: tournamentMatches.filter((match) => match.stage === 'Półfinał').slice(0, 2),
      final: tournamentMatches.filter((match) => match.stage === 'Finał').slice(0, 1),
    }
  }

  const handleGenerate = async () => {
    try {
      await generateBracket(selectedId)
    } catch {
      // Globalny toast pokazuje szczegóły błędu.
    }
  }

  return (
    <div className="page">
      <PageHeader
        eyebrow="Faza pucharowa"
        title="Drabinki"
        description="Automatycznie generuj pary i obserwuj drogę zespołów do finału."
        actions={<button className="button button--primary" type="button" onClick={handleGenerate} disabled={!tournament}><GitFork size={18} /> Generuj drabinkę</button>}
      />

      <section className="bracket-toolbar panel">
        <div><span className="summary-icon summary-icon--violet"><Brackets /></span><span><small>Wybrany turniej</small><select value={selectedId} onChange={(event) => setSelectedId(event.target.value)}>{eligible.map((item) => <option value={item.id} key={item.id}>{item.name}</option>)}</select></span></div>
        {tournament && <div className="bracket-toolbar__meta"><span><small>Format</small><strong>{tournament.format}</strong></span><span><small>Uczestnicy</small><strong>{tournament.participants.length}</strong></span><span><small>Mecze</small><strong>{tournamentMatches.length}</strong></span></div>}
      </section>

      {tournament ? (
        <section className="bracket-stage" aria-label={`Drabinka ${tournament.name}`}>
          <header className="bracket-stage__header"><div><span className="status status--live"><i />Drabinka turniejowa</span><h2>{tournament.name}</h2></div><button className="icon-button" type="button" title="Odśwież widok"><RotateCcw size={18} /></button></header>
          <div className="bracket-scroll">
            <div className="bracket-board">
              <section className="bracket-round bracket-round--quarter"><header><span>01</span><div><strong>Ćwierćfinały</strong><small>8 drużyn</small></div></header><div className="bracket-round__matches">{[0, 1, 2, 3].map((index) => <BracketMatch key={rounds.first[index]?.id ?? `q-${index}`} match={rounds.first[index]} teams={teams} label={`Mecz Q${index + 1}`} />)}</div></section>
              <span className="bracket-arrow"><ChevronRight /></span>
              <section className="bracket-round bracket-round--semi"><header><span>02</span><div><strong>Półfinały</strong><small>4 drużyny</small></div></header><div className="bracket-round__matches">{[0, 1].map((index) => <BracketMatch key={rounds.semi[index]?.id ?? `s-${index}`} match={rounds.semi[index]} teams={teams} label={`Mecz S${index + 1}`} />)}</div></section>
              <span className="bracket-arrow"><ChevronRight /></span>
              <section className="bracket-round bracket-round--final"><header><span>03</span><div><strong>Wielki finał</strong><small>2 drużyny</small></div></header><div className="bracket-round__matches"><BracketMatch match={rounds.final[0]} teams={teams} label="Finał" /></div></section>
              <span className="bracket-arrow"><ChevronRight /></span>
              <section className="bracket-champion"><span><Trophy /></span><small>Mistrz turnieju</small><strong>{tournament.winnerId ? teams.find((team) => team.id === tournament.winnerId)?.name : 'Czeka na finał'}</strong><p>{tournament.winnerId ? 'Gratulacje!' : 'Zwycięzca zostanie wyłoniony w finale.'}</p></section>
            </div>
          </div>
          <footer className="bracket-legend"><span><i className="legend-dot legend-dot--winner" /> Zwycięzca meczu</span><span><i className="legend-dot" /> Oczekuje na wynik</span><p>Na urządzeniu mobilnym przesuń drabinkę poziomo.</p></footer>
        </section>
      ) : <div className="empty-state"><h3>Brak turniejów drużynowych</h3><p>Utwórz turniej, aby wygenerować drabinkę.</p></div>}
    </div>
  )
}
