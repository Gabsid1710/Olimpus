import { useMemo, useState } from 'react'
import { Activity, Gamepad2, Search, Shield, Star, Trophy, UserRound } from 'lucide-react'
import Avatar from '../components/Avatar'
import EmptyState from '../components/EmptyState'
import Modal from '../components/Modal'
import PageHeader from '../components/PageHeader'
import { useArena } from '../context/ArenaContext'

const statusText = { online: 'Online', offline: 'Offline', 'in-game': 'W grze' }

export default function Players() {
  const { players, teams } = useArena()
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const [selected, setSelected] = useState(null)
  const findTeam = (id) => teams.find((team) => team.id === id)
  const filtered = useMemo(() => players.filter((player) => {
    const query = search.toLocaleLowerCase('pl')
    return (status === 'all' || player.status === status) && (!query || `${player.nickname} ${player.name} ${player.game}`.toLocaleLowerCase('pl').includes(query))
  }).sort((a, b) => b.rating - a.rating), [players, search, status])

  return (
    <div className="page">
      <PageHeader eyebrow="Baza zawodników" title="Gracze" description="Profile, role, aktywność oraz ranking wszystkich zarejestrowanych zawodników." />
      <section className="player-summary">
        <div><span className="summary-icon summary-icon--violet"><UserRound /></span><span><small>Wszyscy gracze</small><strong>{players.length}</strong></span></div>
        <div><span className="summary-icon summary-icon--green"><Activity /></span><span><small>Teraz online</small><strong>{players.filter((player) => player.status !== 'offline').length}</strong></span></div>
        <div><span className="summary-icon summary-icon--blue"><Shield /></span><span><small>W drużynach</small><strong>{players.filter((player) => player.teamId).length}</strong></span></div>
      </section>
      <section className="toolbar">
        <label className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Szukaj pseudonimu, nazwiska lub gry…" aria-label="Szukaj gracza" /></label>
        <label className="select-field"><Activity size={17} /><select value={status} onChange={(event) => setStatus(event.target.value)} aria-label="Status gracza"><option value="all">Każdy status</option><option value="online">Online</option><option value="in-game">W grze</option><option value="offline">Offline</option></select></label>
      </section>

      {filtered.length ? (
        <section className="players-table-wrap">
          <table className="data-table players-table">
            <thead><tr><th>#</th><th>Zawodnik</th><th>Drużyna</th><th>Gra / rola</th><th>Rating</th><th>Status</th></tr></thead>
            <tbody>{filtered.map((player, index) => {
              const team = findTeam(player.teamId)
              return <tr key={player.id} onClick={() => setSelected(player)} tabIndex="0" onKeyDown={(event) => { if (event.key === 'Enter') setSelected(player) }}><td><span className={`rank-number ${index < 3 ? 'rank-number--top' : ''}`}>{index + 1}</span></td><td><div className="table-person"><Avatar name={player.nickname} color={team?.color} size="small" status={player.status} /><span><strong>{player.nickname}</strong><small>{player.name}</small></span></div></td><td>{team ? <span className="team-tag" style={{ '--tag-color': team.color }}>{team.tag}</span> : <span className="muted">Bez drużyny</span>}</td><td><strong>{player.game}</strong><small className="table-subline">{player.role}</small></td><td><span className="rating"><Star size={14} /> {player.rating}</span></td><td><span className={`presence presence--${player.status}`}><i />{statusText[player.status]}</span></td></tr>
            })}</tbody>
          </table>
        </section>
      ) : <EmptyState title="Nie znaleziono graczy" description="Spróbuj zmienić frazę lub filtr statusu." />}

      <Modal open={Boolean(selected)} onClose={() => setSelected(null)} title={selected?.nickname ?? ''} eyebrow="Profil zawodnika">
        {selected && (() => {
          const team = findTeam(selected.teamId)
          return <div className="player-profile"><div className="player-profile__hero"><Avatar name={selected.nickname} color={team?.color} size="xlarge" status={selected.status} /><div><span className={`presence presence--${selected.status}`}><i />{statusText[selected.status]}</span><h3>{selected.nickname}</h3><p>{selected.name}</p></div></div><div className="profile-metrics"><div><Star /><strong>{selected.rating}</strong><small>rating</small></div><div><Trophy /><strong>#{players.slice().sort((a, b) => b.rating - a.rating).findIndex((item) => item.id === selected.id) + 1}</strong><small>ranking</small></div><div><Gamepad2 /><strong>{selected.role}</strong><small>rola</small></div></div><section className="profile-team"><h3>Drużyna</h3>{team ? <div><Avatar name={team.tag} color={team.color} size="medium" /><span><strong>{team.name}</strong><small>{team.game} • {team.wins} wygranych</small></span></div> : <p className="muted">Gracz nie należy do drużyny.</p>}</section></div>
        })()}
      </Modal>
    </div>
  )
}
