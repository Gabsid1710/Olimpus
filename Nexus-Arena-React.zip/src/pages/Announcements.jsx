import { useState } from 'react'
import { AlertTriangle, BellRing, Info, Megaphone, Pin, Plus, RefreshCw, Send } from 'lucide-react'
import Modal from '../components/Modal'
import PageHeader from '../components/PageHeader'
import { useArena } from '../context/ArenaContext'
import { formatDateTime } from '../utils/formatters'

const iconMap = { info: Info, important: AlertTriangle, update: RefreshCw }
const labelMap = { info: 'Informacja', important: 'Ważne', update: 'Aktualizacja' }

function AnnouncementModal({ open, onClose }) {
  const { createAnnouncement } = useArena()
  const [form, setForm] = useState({ title: '', body: '', type: 'info', pinned: false })
  const [submitting, setSubmitting] = useState(false)
  const submit = async (event) => {
    event.preventDefault()
    setSubmitting(true)
    try {
      await createAnnouncement(form)
      setForm({ title: '', body: '', type: 'info', pinned: false })
      onClose()
    } catch { /* toast */ } finally { setSubmitting(false) }
  }
  return <Modal open={open} onClose={onClose} title="Nowy komunikat" eyebrow="Publikacja"><form className="form-grid" onSubmit={submit}><label className="field form-grid__full"><span>Tytuł</span><input required minLength="3" maxLength="80" value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="Najważniejsza informacja" /></label><label className="field form-grid__full"><span>Treść komunikatu</span><textarea required minLength="10" rows="5" maxLength="400" value={form.body} onChange={(event) => setForm({ ...form, body: event.target.value })} placeholder="Napisz wiadomość do uczestników…" /><small>{form.body.length}/400</small></label><label className="field"><span>Rodzaj</span><select value={form.type} onChange={(event) => setForm({ ...form, type: event.target.value })}><option value="info">Informacja</option><option value="important">Ważne</option><option value="update">Aktualizacja</option></select></label><label className="check-field"><input type="checkbox" checked={form.pinned} onChange={(event) => setForm({ ...form, pinned: event.target.checked })} /><span><strong>Przypnij komunikat</strong><small>Pokaż jako najważniejszy</small></span></label><div className="modal__actions form-grid__full"><button className="button button--ghost" type="button" onClick={onClose}>Anuluj</button><button className="button button--primary" disabled={submitting}><Send size={17} /> {submitting ? 'Publikowanie…' : 'Opublikuj'}</button></div></form></Modal>
}

export default function Announcements() {
  const { announcements } = useArena()
  const [createOpen, setCreateOpen] = useState(false)
  const sorted = [...announcements].sort((a, b) => Number(b.pinned) - Number(a.pinned) || new Date(b.publishedAt) - new Date(a.publishedAt))
  return <div className="page"><PageHeader eyebrow="Tablica informacyjna" title="Komunikaty" description="Publikuj ważne informacje dla organizatorów, drużyn i zawodników." actions={<button className="button button--primary" type="button" onClick={() => setCreateOpen(true)}><Plus size={18} /> Nowy komunikat</button>} /><section className="announcement-feature"><span><BellRing /></span><div><small>Centrum komunikacji</small><h2>Wszystko, co ważne, w jednym miejscu</h2><p>Przypięte wiadomości są widoczne w powiadomieniach każdego użytkownika.</p></div></section><section className="announcements-list">{sorted.map((announcement) => { const Icon = iconMap[announcement.type] ?? Info; return <article className={`announcement-card announcement-card--${announcement.type}`} key={announcement.id}><span className="announcement-card__icon"><Icon /></span><div><header><span className="announcement-card__type">{labelMap[announcement.type]}</span>{announcement.pinned && <span className="pinned"><Pin size={13} /> Przypięty</span>}<time dateTime={announcement.publishedAt}>{formatDateTime(announcement.publishedAt)}</time></header><h2>{announcement.title}</h2><p>{announcement.body}</p><footer><span><Megaphone size={14} /> Nexus Arena</span><button className="text-button" type="button">Oznacz jako przeczytane</button></footer></div></article> })}</section><AnnouncementModal open={createOpen} onClose={() => setCreateOpen(false)} /></div>
}
