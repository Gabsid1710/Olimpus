import { ArrowLeft, MapPinOff } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return <div className="not-found"><span><MapPinOff /></span><small>Błąd 404</small><h1>Ta arena nie istnieje</h1><p>Wybrana strona została przeniesiona albo podany adres jest nieprawidłowy.</p><Link className="button button--primary" to="/"><ArrowLeft size={17} /> Wróć do panelu</Link></div>
}
