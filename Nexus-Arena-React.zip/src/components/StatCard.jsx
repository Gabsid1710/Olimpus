import { ArrowUpRight } from 'lucide-react'

export default function StatCard({ icon: Icon, label, value, detail, tone = 'violet', onClick }) {
  const content = (
    <>
      <span className={`stat-card__icon stat-card__icon--${tone}`}><Icon size={22} /></span>
      <span className="stat-card__content">
        <small>{label}</small>
        <strong>{value}</strong>
        <span>{detail} <ArrowUpRight size={13} /></span>
      </span>
    </>
  )

  if (onClick) {
    return <button type="button" className="stat-card" onClick={onClick}>{content}</button>
  }
  return <article className="stat-card">{content}</article>
}
