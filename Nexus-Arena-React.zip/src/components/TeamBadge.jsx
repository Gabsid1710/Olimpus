import Avatar from './Avatar'

export default function TeamBadge({ team, compact = false, align = 'start' }) {
  if (!team) return <span className="muted">TBA</span>
  return (
    <div className={`team-badge team-badge--${align} ${compact ? 'team-badge--compact' : ''}`}>
      <Avatar name={team.tag || team.name} color={team.color} size={compact ? 'small' : 'medium'} />
      <span>
        <strong>{team.name}</strong>
        {!compact && <small>{team.tag}</small>}
      </span>
    </div>
  )
}
