import { useEffect, useRef, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import {
  Bell,
  Brackets,
  ChevronDown,
  ChevronLeft,
  CircleHelp,
  Gamepad2,
  Home,
  LogOut,
  Menu,
  Megaphone,
  Plus,
  Radio,
  Settings,
  ShieldCheck,
  Swords,
  Trophy,
  UserRound,
  UsersRound,
  X,
} from 'lucide-react'
import { useArena } from '../context/ArenaContext'
import Avatar from './Avatar'
import CreateTournamentModal from './CreateTournamentModal'
import Logo from './Logo'
import Toast from './Toast'

const navigation = [
  { to: '/', label: 'Panel główny', icon: Home },
  { to: '/turnieje', label: 'Turnieje', icon: Trophy },
  { to: '/zespoly', label: 'Zespoły', icon: UsersRound },
  { to: '/gracze', label: 'Gracze', icon: UserRound },
  { to: '/drabinki', label: 'Drabinki', icon: Brackets },
  { to: '/mecze', label: 'Mecze', icon: Gamepad2 },
  { to: '/wyniki', label: 'Wyniki', icon: Swords },
  { to: '/transmisje', label: 'Transmisje', icon: Radio },
  { to: '/komunikaty', label: 'Komunikaty', icon: Megaphone },
  { to: '/ustawienia', label: 'Ustawienia', icon: Settings },
]

const pathLabels = Object.fromEntries(navigation.map(({ to, label }) => [to, label]))

export default function Layout() {
  const { settings: settingRecords, announcements, toast, dismissToast } = useArena()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [notificationOpen, setNotificationOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()
  const dropdownRef = useRef(null)
  const appSettings = settingRecords.find((item) => item.id === 'app')
  const profile = appSettings?.profile ?? { name: 'Użytkownik', nickname: 'Gracz', role: 'Administrator' }

  useEffect(() => {
    const closeDropdowns = (event) => {
      if (!dropdownRef.current?.contains(event.target)) {
        setNotificationOpen(false)
        setUserOpen(false)
      }
    }
    document.addEventListener('pointerdown', closeDropdowns)
    return () => document.removeEventListener('pointerdown', closeDropdowns)
  }, [])

  const activeLabel = pathLabels[location.pathname] ?? 'Nexus Arena'
  const unreadCount = announcements.filter((announcement) => announcement.pinned).length

  return (
    <div className={`app-shell ${collapsed ? 'app-shell--collapsed' : ''}`}>
      <a className="skip-link" href="#main-content">Przejdź do treści</a>
      <aside className={`sidebar ${sidebarOpen ? 'sidebar--open' : ''}`} aria-label="Główna nawigacja">
        <div className="sidebar__top">
          <Logo compact={collapsed} />
          <button className="icon-button sidebar__mobile-close" type="button" aria-label="Zamknij menu" onClick={() => setSidebarOpen(false)}>
            <X size={20} />
          </button>
        </div>

        <nav className="sidebar__nav">
          {navigation.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) => `nav-link ${isActive ? 'nav-link--active' : ''}`}
              title={collapsed ? label : undefined}
              onClick={() => setSidebarOpen(false)}
            >
              <Icon size={19} />
              <span>{label}</span>
              {label === 'Komunikaty' && unreadCount > 0 && <b>{unreadCount}</b>}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar__status">
          {!collapsed && (
            <>
              <span><ShieldCheck size={17} /> Dane lokalne</span>
              <small>IndexedDB • aktywna</small>
            </>
          )}
        </div>
        <button className="sidebar__collapse" type="button" onClick={() => setCollapsed((value) => !value)}>
          <ChevronLeft size={17} />
          <span>{collapsed ? 'Rozwiń' : 'Zwiń menu'}</span>
        </button>
      </aside>

      {sidebarOpen && <button className="sidebar-overlay" aria-label="Zamknij menu" type="button" onClick={() => setSidebarOpen(false)} />}

      <header className="topbar">
        <div className="topbar__left">
          <button className="icon-button menu-button" type="button" aria-label="Otwórz menu" onClick={() => setSidebarOpen(true)}>
            <Menu size={22} />
          </button>
          <div className="topbar__title">
            <small>Centrum turniejowe</small>
            <strong>{activeLabel}</strong>
          </div>
        </div>

        <div className="topbar__right" ref={dropdownRef}>
          <button className="button button--primary topbar__create" type="button" onClick={() => setCreateOpen(true)}>
            <Plus size={17} /> <span>Utwórz turniej</span>
          </button>
          <div className="dropdown-anchor">
            <button
              className="icon-button notification-button"
              type="button"
              aria-label={`Powiadomienia: ${unreadCount} nowe`}
              aria-expanded={notificationOpen}
              onClick={() => { setNotificationOpen((value) => !value); setUserOpen(false) }}
            >
              <Bell size={20} />
              {unreadCount > 0 && <span />}
            </button>
            {notificationOpen && (
              <section className="dropdown dropdown--notifications">
                <header><strong>Powiadomienia</strong><small>{unreadCount} nowe</small></header>
                {announcements.slice(0, 3).map((item) => (
                  <button key={item.id} type="button" onClick={() => navigate('/komunikaty')}>
                    <span className={`notice-dot notice-dot--${item.type}`} />
                    <span><strong>{item.title}</strong><small>{item.body.slice(0, 65)}…</small></span>
                  </button>
                ))}
                <button className="dropdown__footer" type="button" onClick={() => navigate('/komunikaty')}>Zobacz wszystkie</button>
              </section>
            )}
          </div>

          <div className="dropdown-anchor">
            <button
              className="user-chip"
              type="button"
              aria-expanded={userOpen}
              onClick={() => { setUserOpen((value) => !value); setNotificationOpen(false) }}
            >
              <Avatar name={profile.nickname} size="medium" />
              <span><strong>{profile.nickname}</strong><small>{profile.role}</small></span>
              <ChevronDown size={15} />
            </button>
            {userOpen && (
              <section className="dropdown dropdown--user">
                <div className="dropdown__profile">
                  <Avatar name={profile.nickname} size="large" />
                  <span><strong>{profile.name}</strong><small>{profile.email}</small></span>
                </div>
                <button type="button" onClick={() => navigate('/ustawienia')}><Settings size={17} /> Ustawienia konta</button>
                <button type="button" onClick={() => navigate('/komunikaty')}><CircleHelp size={17} /> Centrum pomocy</button>
                <button type="button" className="danger-text"><LogOut size={17} /> Wyloguj (demo)</button>
              </section>
            )}
          </div>
        </div>
      </header>

      <main id="main-content" className="main-content" tabIndex="-1">
        <Outlet context={{ openCreateTournament: () => setCreateOpen(true) }} />
      </main>

      <CreateTournamentModal open={createOpen} onClose={() => setCreateOpen(false)} />
      <Toast toast={toast} onClose={dismissToast} />
    </div>
  )
}
