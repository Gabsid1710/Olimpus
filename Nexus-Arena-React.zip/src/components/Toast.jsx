import { useEffect } from 'react'
import { CheckCircle2, X, XCircle } from 'lucide-react'

export default function Toast({ toast, onClose }) {
  useEffect(() => {
    if (!toast) return undefined
    const timer = window.setTimeout(onClose, 4200)
    return () => window.clearTimeout(timer)
  }, [toast, onClose])

  if (!toast) return null

  return (
    <div className={`toast toast--${toast.type}`} role="status" aria-live="polite">
      {toast.type === 'error' ? <XCircle size={20} /> : <CheckCircle2 size={20} />}
      <span>{toast.message}</span>
      <button type="button" aria-label="Zamknij powiadomienie" onClick={onClose}>
        <X size={16} />
      </button>
    </div>
  )
}
