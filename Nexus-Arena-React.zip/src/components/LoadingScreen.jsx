import Logo from './Logo'

export default function LoadingScreen() {
  return (
    <main className="loading-screen" aria-live="polite">
      <Logo />
      <span className="spinner" />
      <p>Uruchamianie lokalnej areny…</p>
    </main>
  )
}
