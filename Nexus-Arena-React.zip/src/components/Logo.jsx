export default function Logo({ compact = false }) {
  return (
    <div className={`brand ${compact ? 'brand--compact' : ''}`} aria-label="Nexus Arena">
      <span className="brand__mark" aria-hidden="true">
        <span>N</span>
      </span>
      {!compact && (
        <span className="brand__copy">
          <strong>NEXUS</strong>
          <small>ARENA</small>
        </span>
      )}
    </div>
  )
}
