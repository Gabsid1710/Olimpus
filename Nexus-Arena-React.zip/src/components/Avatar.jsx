import { initials } from '../utils/formatters'

export default function Avatar({ name, color = '#8b5cf6', size = 'medium', status }) {
  return (
    <span
      className={`avatar avatar--${size}`}
      style={{ '--avatar-color': color }}
      aria-label={name}
    >
      {initials(name)}
      {status && <span className={`avatar__status avatar__status--${status}`} aria-hidden="true" />}
    </span>
  )
}
