import { Crosshair, Gamepad2, Swords, Trophy } from 'lucide-react'

const gameIcons = {
  'Counter-Strike 2': Crosshair,
  Valorant: Swords,
  'League of Legends': Trophy,
}

export default function TournamentCover({ tournament, size = 'medium' }) {
  const Icon = gameIcons[tournament.game] ?? Gamepad2
  return (
    <div className={`tournament-cover tournament-cover--${tournament.cover || 'violet'} tournament-cover--${size}`} aria-hidden="true">
      <span className="tournament-cover__grid" />
      <span className="tournament-cover__glow" />
      <Icon />
      <small>{tournament.game}</small>
    </div>
  )
}
