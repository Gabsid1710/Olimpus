import { useMemo, useState } from 'react'
import { CalendarDays, Trophy } from 'lucide-react'
import { useArena } from '../context/ArenaContext'
import Modal from './Modal'

const games = ['Counter-Strike 2', 'Valorant', 'League of Legends', 'Rocket League', 'Fortnite', 'Overwatch 2']
const formats = ['Pojedyncza eliminacja', 'Podwójna eliminacja', 'Faza grupowa + playoff', 'System szwajcarski', 'Punkty po 5 mapach']

function getDefaultDate() {
  const date = new Date()
  date.setDate(date.getDate() + 7)
  date.setHours(18, 0, 0, 0)
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 16)
}

const initialForm = {
  name: '',
  game: 'Counter-Strike 2',
  mode: 'Drużynowy 5v5',
  format: 'Pojedyncza eliminacja',
  maxParticipants: 16,
  startDate: '',
  prizePool: 0,
  description: '',
  cover: 'violet',
}

export default function CreateTournamentModal({ open, onClose }) {
  const { createTournament } = useArena()
  const [form, setForm] = useState(initialForm)
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState('')
  const defaultDate = useMemo(() => getDefaultDate(), [])

  const handleChange = (event) => {
    const { name, value } = event.target
    setForm((current) => ({ ...current, [name]: value }))
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setFormError('')
    if (form.name.trim().length < 3) {
      setFormError('Nazwa turnieju musi mieć co najmniej 3 znaki.')
      return
    }

    setSubmitting(true)
    try {
      await createTournament({ ...form, startDate: form.startDate || defaultDate })
      setForm({ ...initialForm, startDate: '' })
      onClose()
    } catch {
      setFormError('Nie udało się utworzyć turnieju. Spróbuj ponownie.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Nowy turniej" eyebrow="Kreator rozgrywek" size="large">
      <form className="form-grid" onSubmit={handleSubmit}>
        <div className="form-intro form-grid__full">
          <span className="form-intro__icon"><Trophy size={24} /></span>
          <div>
            <strong>Zaplanuj nowe wydarzenie</strong>
            <p>Ustaw zasady, limit uczestników i termin. Dane zostaną zapisane lokalnie.</p>
          </div>
        </div>

        <label className="field form-grid__full">
          <span>Nazwa turnieju</span>
          <input name="name" value={form.name} onChange={handleChange} placeholder="np. Nexus Community Cup" required maxLength={60} />
        </label>

        <label className="field">
          <span>Gra</span>
          <select name="game" value={form.game} onChange={handleChange}>
            {games.map((game) => <option key={game}>{game}</option>)}
          </select>
        </label>

        <label className="field">
          <span>Tryb</span>
          <select name="mode" value={form.mode} onChange={handleChange}>
            <option>Drużynowy 5v5</option>
            <option>Drużynowy 3v3</option>
            <option>Drużynowy 2v2</option>
            <option>Solo</option>
          </select>
        </label>

        <label className="field">
          <span>Format rozgrywek</span>
          <select name="format" value={form.format} onChange={handleChange}>
            {formats.map((format) => <option key={format}>{format}</option>)}
          </select>
        </label>

        <label className="field">
          <span>Limit uczestników</span>
          <input name="maxParticipants" type="number" min="2" max="128" value={form.maxParticipants} onChange={handleChange} required />
        </label>

        <label className="field">
          <span><CalendarDays size={15} /> Data rozpoczęcia</span>
          <input name="startDate" type="datetime-local" value={form.startDate || defaultDate} onChange={handleChange} required />
        </label>

        <label className="field">
          <span>Pula nagród (PLN)</span>
          <input name="prizePool" type="number" min="0" step="100" value={form.prizePool} onChange={handleChange} />
        </label>

        <label className="field form-grid__full">
          <span>Krótki opis</span>
          <textarea name="description" rows="3" value={form.description} onChange={handleChange} placeholder="Napisz, dla kogo jest turniej i jakie są najważniejsze zasady…" maxLength={280} />
          <small>{form.description.length}/280</small>
        </label>

        {formError && <p className="form-error form-grid__full" role="alert">{formError}</p>}

        <div className="modal__actions form-grid__full">
          <button className="button button--ghost" type="button" onClick={onClose}>Anuluj</button>
          <button className="button button--primary" type="submit" disabled={submitting}>
            {submitting ? 'Tworzenie…' : 'Utwórz turniej'}
          </button>
        </div>
      </form>
    </Modal>
  )
}
