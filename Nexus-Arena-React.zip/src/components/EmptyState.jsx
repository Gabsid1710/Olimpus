import { SearchX } from 'lucide-react'

export default function EmptyState({ title = 'Brak wyników', description, action }) {
  return (
    <div className="empty-state">
      <span className="empty-state__icon"><SearchX size={26} /></span>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {action}
    </div>
  )
}
