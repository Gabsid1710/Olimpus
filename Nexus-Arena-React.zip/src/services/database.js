import { createSeedData } from '../data/seedData'

const DATABASE_NAME = 'nexus-arena-local'
const DATABASE_VERSION = 1
export const STORE_NAMES = [
  'tournaments',
  'teams',
  'players',
  'matches',
  'activities',
  'announcements',
  'settings',
]

let databasePromise

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

function transactionToPromise(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve()
    transaction.onerror = () => reject(transaction.error)
    transaction.onabort = () => reject(transaction.error ?? new Error('Transakcja została przerwana.'))
  })
}

export function openDatabase() {
  if (databasePromise) return databasePromise

  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION)

    request.onupgradeneeded = () => {
      const database = request.result
      STORE_NAMES.forEach((storeName) => {
        if (!database.objectStoreNames.contains(storeName)) {
          database.createObjectStore(storeName, { keyPath: 'id' })
        }
      })
    }

    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
    request.onblocked = () => reject(new Error('Baza jest zablokowana w innej karcie.'))
  })

  return databasePromise
}

export async function initializeDatabase() {
  const database = await openDatabase()
  const countTransaction = database.transaction('tournaments', 'readonly')
  const count = await requestToPromise(countTransaction.objectStore('tournaments').count())

  if (count > 0) return

  const seed = createSeedData()
  const transaction = database.transaction(STORE_NAMES, 'readwrite')
  STORE_NAMES.forEach((storeName) => {
    seed[storeName].forEach((record) => transaction.objectStore(storeName).put(record))
  })
  await transactionToPromise(transaction)
}

function validateStore(storeName) {
  if (!STORE_NAMES.includes(storeName)) {
    throw new Error(`Nieznany magazyn danych: ${storeName}`)
  }
}

export async function getAll(storeName) {
  validateStore(storeName)
  const database = await openDatabase()
  const transaction = database.transaction(storeName, 'readonly')
  return requestToPromise(transaction.objectStore(storeName).getAll())
}

export async function getRecord(storeName, id) {
  validateStore(storeName)
  const database = await openDatabase()
  const transaction = database.transaction(storeName, 'readonly')
  return requestToPromise(transaction.objectStore(storeName).get(id))
}

export async function saveRecord(storeName, record) {
  validateStore(storeName)
  const database = await openDatabase()
  const transaction = database.transaction(storeName, 'readwrite')
  transaction.objectStore(storeName).put(record)
  await transactionToPromise(transaction)
  return record
}

export async function deleteRecord(storeName, id) {
  validateStore(storeName)
  const database = await openDatabase()
  const transaction = database.transaction(storeName, 'readwrite')
  transaction.objectStore(storeName).delete(id)
  await transactionToPromise(transaction)
}

export async function exportDatabase() {
  const entries = await Promise.all(STORE_NAMES.map(async (storeName) => [storeName, await getAll(storeName)]))
  return {
    app: 'Nexus Arena',
    version: DATABASE_VERSION,
    exportedAt: new Date().toISOString(),
    data: Object.fromEntries(entries),
  }
}

export async function importDatabase(backup) {
  if (!backup?.data || typeof backup.data !== 'object') {
    throw new Error('Wybrany plik nie jest prawidłową kopią Nexus Arena.')
  }

  const database = await openDatabase()
  const transaction = database.transaction(STORE_NAMES, 'readwrite')

  STORE_NAMES.forEach((storeName) => {
    const store = transaction.objectStore(storeName)
    store.clear()
    const records = Array.isArray(backup.data[storeName]) ? backup.data[storeName] : []
    records.forEach((record) => store.put(record))
  })

  await transactionToPromise(transaction)
}

export async function resetDatabase() {
  const database = await openDatabase()
  const seed = createSeedData()
  const transaction = database.transaction(STORE_NAMES, 'readwrite')

  STORE_NAMES.forEach((storeName) => {
    const store = transaction.objectStore(storeName)
    store.clear()
    seed[storeName].forEach((record) => store.put(record))
  })

  await transactionToPromise(transaction)
}
