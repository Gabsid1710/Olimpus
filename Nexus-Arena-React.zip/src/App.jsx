import { AlertTriangle, RefreshCw } from 'lucide-react'
import { Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import LoadingScreen from './components/LoadingScreen'
import { useArena } from './context/ArenaContext'
import Announcements from './pages/Announcements'
import BracketsPage from './pages/BracketsPage'
import Dashboard from './pages/Dashboard'
import Matches from './pages/Matches'
import NotFound from './pages/NotFound'
import Players from './pages/Players'
import Results from './pages/Results'
import SettingsPage from './pages/SettingsPage'
import Streams from './pages/Streams'
import Teams from './pages/Teams'
import Tournaments from './pages/Tournaments'
import './App.css'

export default function App() {
  const { loading, error } = useArena()

  if (loading) return <LoadingScreen />
  if (error) {
    return (
      <main className="error-screen">
        <span><AlertTriangle /></span>
        <h1>Nie udało się uruchomić aplikacji</h1>
        <p>{error}</p>
        <button className="button button--primary" type="button" onClick={() => window.location.reload()}><RefreshCw size={17} /> Spróbuj ponownie</button>
      </main>
    )
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="turnieje" element={<Tournaments />} />
        <Route path="zespoly" element={<Teams />} />
        <Route path="gracze" element={<Players />} />
        <Route path="drabinki" element={<BracketsPage />} />
        <Route path="mecze" element={<Matches />} />
        <Route path="wyniki" element={<Results />} />
        <Route path="transmisje" element={<Streams />} />
        <Route path="komunikaty" element={<Announcements />} />
        <Route path="ustawienia" element={<SettingsPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
