import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import {
  STORE_NAMES,
  deleteRecord,
  exportDatabase,
  getAll,
  importDatabase,
  initializeDatabase,
  resetDatabase,
  saveRecord,
} from '../services/database'
import { createId } from '../utils/formatters'

const ArenaContext = createContext(null)

const emptyData = Object.fromEntries(STORE_NAMES.map((storeName) => [storeName, []]))

export function ArenaProvider({ children }) {
  const [data, setData] = useState(emptyData)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [toast, setToast] = useState(null)

  const notify = useCallback((message, type = 'success') => {
    setToast({ id: Date.now(), message, type })
  }, [])

  const loadData = useCallback(async () => {
    const entries = await Promise.all(
      STORE_NAMES.map(async (storeName) => [storeName, await getAll(storeName)]),
    )
    setData(Object.fromEntries(entries))
  }, [])

  useEffect(() => {
    let active = true

    async function start() {
      try {
        await initializeDatabase()
        if (!active) return
        await loadData()
      } catch (databaseError) {
        if (active) setError(databaseError.message || 'Nie udało się uruchomić lokalnej bazy danych.')
      } finally {
        if (active) setLoading(false)
      }
    }

    start()
    return () => {
      active = false
    }
  }, [loadData])

  const runMutation = useCallback(
    async (operation, successMessage) => {
      try {
        await operation()
        await loadData()
        if (successMessage) notify(successMessage)
      } catch (mutationError) {
        notify(mutationError.message || 'Operacja nie powiodła się.', 'error')
        throw mutationError
      }
    },
    [loadData, notify],
  )

  const addActivity = useCallback(async (type, message) => {
    await saveRecord('activities', {
      id: createId('activity'),
      type,
      message,
      createdAt: new Date().toISOString(),
    })
  }, [])

  const createTournament = useCallback(
    async (formData) => {
      const tournament = {
        id: createId('tournament'),
        name: formData.name.trim(),
        game: formData.game,
        mode: formData.mode,
        format: formData.format,
        status: 'registration',
        maxParticipants: Number(formData.maxParticipants),
        participants: [],
        startDate: new Date(formData.startDate).toISOString(),
        prizePool: Number(formData.prizePool) || 0,
        organizer: 'Nexus Arena',
        description: formData.description.trim(),
        cover: formData.cover || 'violet',
      }

      await runMutation(async () => {
        await saveRecord('tournaments', tournament)
        await addActivity('tournament', `Utworzono turniej ${tournament.name}`)
      }, `Turniej „${tournament.name}” został utworzony.`)

      return tournament
    },
    [addActivity, runMutation],
  )

  const toggleTournamentRegistration = useCallback(
    async (tournamentId) => {
      const tournament = data.tournaments.find((item) => item.id === tournamentId)
      const appSettings = data.settings.find((item) => item.id === 'app')
      if (!tournament || !appSettings) throw new Error('Nie znaleziono turnieju lub profilu.')

      const participantId = tournament.mode === 'Solo' ? 'player-user' : appSettings.currentTeamId
      const isRegistered = tournament.participants.includes(participantId)

      if (!isRegistered && tournament.participants.length >= tournament.maxParticipants) {
        throw new Error('Brak wolnych miejsc w tym turnieju.')
      }

      const participants = isRegistered
        ? tournament.participants.filter((id) => id !== participantId)
        : [...tournament.participants, participantId]

      await runMutation(async () => {
        await saveRecord('tournaments', { ...tournament, participants })
        await addActivity(
          'join',
          `${isRegistered ? 'Wycofano zgłoszenie z' : 'Dołączono do'} turnieju ${tournament.name}`,
        )
      }, isRegistered ? 'Zgłoszenie zostało wycofane.' : 'Dołączono do turnieju. Powodzenia!')
    },
    [addActivity, data.settings, data.tournaments, runMutation],
  )

  const deleteTournament = useCallback(
    async (tournamentId) => {
      const tournament = data.tournaments.find((item) => item.id === tournamentId)
      if (!tournament) return

      await runMutation(async () => {
        const relatedMatches = data.matches.filter((match) => match.tournamentId === tournamentId)
        await Promise.all(relatedMatches.map((match) => deleteRecord('matches', match.id)))
        await deleteRecord('tournaments', tournamentId)
        await addActivity('tournament', `Usunięto turniej ${tournament.name}`)
      }, 'Turniej został usunięty.')
    },
    [addActivity, data.matches, data.tournaments, runMutation],
  )

  const createTeam = useCallback(
    async (teamData) => {
      const team = {
        id: createId('team'),
        name: teamData.name.trim(),
        tag: teamData.tag.trim().toUpperCase(),
        game: teamData.game,
        color: teamData.color || '#8b5cf6',
        wins: 0,
        losses: 0,
        ranking: data.teams.length + 1,
        members: Number(teamData.members) || 1,
      }

      await runMutation(async () => {
        await saveRecord('teams', team)
        await addActivity('team', `Zarejestrowano drużynę ${team.name}`)
      }, `Drużyna „${team.name}” została dodana.`)
      return team
    },
    [addActivity, data.teams.length, runMutation],
  )

  const updateMatch = useCallback(
    async (matchId, scoreA, scoreB) => {
      const match = data.matches.find((item) => item.id === matchId)
      if (!match) throw new Error('Nie znaleziono meczu.')
      const teamA = data.teams.find((team) => team.id === match.teamAId)?.name ?? 'Drużyna A'
      const teamB = data.teams.find((team) => team.id === match.teamBId)?.name ?? 'Drużyna B'

      await runMutation(async () => {
        await saveRecord('matches', {
          ...match,
          scoreA: Number(scoreA),
          scoreB: Number(scoreB),
          status: 'finished',
        })
        await addActivity('result', `Mecz ${teamA} vs ${teamB} zakończył się wynikiem ${scoreA} : ${scoreB}`)
      }, 'Wynik meczu został zapisany.')
    },
    [addActivity, data.matches, data.teams, runMutation],
  )

  const generateBracket = useCallback(
    async (tournamentId) => {
      const tournament = data.tournaments.find((item) => item.id === tournamentId)
      if (!tournament) throw new Error('Nie znaleziono turnieju.')
      const participants = tournament.participants.filter((id) => data.teams.some((team) => team.id === id))
      if (participants.length < 2) throw new Error('Do wygenerowania drabinki potrzebnych jest co najmniej 2 uczestników.')

      const existingMatches = data.matches.filter((match) => match.tournamentId === tournamentId)
      if (existingMatches.length > 0) {
        notify('Ten turniej ma już wygenerowaną drabinkę.', 'error')
        return
      }

      const stage = participants.length > 4 ? 'Ćwierćfinał' : participants.length > 2 ? 'Półfinał' : 'Finał'
      const startDate = new Date(tournament.startDate)
      const pairings = []
      for (let index = 0; index + 1 < Math.min(participants.length, 8); index += 2) {
        const matchDate = new Date(startDate)
        matchDate.setHours(matchDate.getHours() + pairings.length * 2)
        pairings.push({
          id: createId('match'),
          tournamentId,
          teamAId: participants[index],
          teamBId: participants[index + 1],
          date: matchDate.toISOString(),
          stage,
          bestOf: 3,
          status: 'scheduled',
          scoreA: null,
          scoreB: null,
          stream: pairings.length === 0,
        })
      }

      await runMutation(async () => {
        await Promise.all(pairings.map((match) => saveRecord('matches', match)))
        await addActivity('tournament', `Wygenerowano drabinkę turnieju ${tournament.name}`)
      }, `Wygenerowano ${pairings.length} ${pairings.length === 1 ? 'mecz' : 'mecze'} pierwszej rundy.`)
    },
    [addActivity, data.matches, data.teams, data.tournaments, notify, runMutation],
  )

  const createAnnouncement = useCallback(
    async ({ title, body, type, pinned }) => {
      await runMutation(async () => {
        await saveRecord('announcements', {
          id: createId('announcement'),
          title: title.trim(),
          body: body.trim(),
          type,
          pinned,
          publishedAt: new Date().toISOString(),
        })
        await addActivity('announcement', `Opublikowano komunikat: ${title.trim()}`)
      }, 'Komunikat został opublikowany.')
    },
    [addActivity, runMutation],
  )

  const updateSettings = useCallback(
    async (nextSettings) => {
      await runMutation(
        () => saveRecord('settings', { ...nextSettings, id: 'app' }),
        'Ustawienia zostały zapisane.',
      )
    },
    [runMutation],
  )

  const downloadBackup = useCallback(async () => {
    const backup = await exportDatabase()
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `nexus-arena-backup-${new Date().toISOString().slice(0, 10)}.json`
    link.click()
    URL.revokeObjectURL(url)
    notify('Kopia lokalnej bazy została pobrana.')
  }, [notify])

  const restoreBackup = useCallback(
    async (file) => {
      try {
        const backup = JSON.parse(await file.text())
        await importDatabase(backup)
        await loadData()
        notify('Kopia danych została przywrócona.')
      } catch (restoreError) {
        notify(restoreError.message || 'Nie udało się przywrócić kopii.', 'error')
      }
    },
    [loadData, notify],
  )

  const resetAllData = useCallback(async () => {
    await resetDatabase()
    await loadData()
    notify('Przywrócono dane demonstracyjne.')
  }, [loadData, notify])

  const value = useMemo(
    () => ({
      ...data,
      loading,
      error,
      toast,
      dismissToast: () => setToast(null),
      notify,
      createTournament,
      toggleTournamentRegistration,
      deleteTournament,
      createTeam,
      updateMatch,
      generateBracket,
      createAnnouncement,
      updateSettings,
      downloadBackup,
      restoreBackup,
      resetAllData,
    }),
    [
      data,
      loading,
      error,
      toast,
      notify,
      createTournament,
      toggleTournamentRegistration,
      deleteTournament,
      createTeam,
      updateMatch,
      generateBracket,
      createAnnouncement,
      updateSettings,
      downloadBackup,
      restoreBackup,
      resetAllData,
    ],
  )

  return <ArenaContext.Provider value={value}>{children}</ArenaContext.Provider>
}

// Provider i hook celowo współdzielą ten sam moduł kontekstu.
// eslint-disable-next-line react-refresh/only-export-components
export function useArena() {
  const context = useContext(ArenaContext)
  if (!context) throw new Error('useArena musi być używany wewnątrz ArenaProvider.')
  return context
}
