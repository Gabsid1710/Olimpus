# Nexus Arena

Responsywna aplikacja React do organizowania turniejów gier komputerowych, zgłaszania drużyn i zawodników, generowania drabinek oraz zapisywania wyników.

## Uruchomienie

Wymagany jest Node.js 20 lub nowszy.

```bash
npm install
npm run dev
```

Wersja produkcyjna:

```bash
npm run build
npm run preview
```

## Najważniejsze funkcje

- responsywny panel administracyjny inspirowany dostarczonym projektem,
- tworzenie, przeglądanie, filtrowanie i usuwanie turniejów,
- dołączanie drużyny lub gracza do otwartych zapisów,
- baza drużyn i zawodników z rankingiem oraz profilami,
- generowanie pierwszej rundy drabinki,
- terminarz meczów i zapisywanie wyników,
- ranking, transmisje, czat demonstracyjny i komunikaty,
- edycja profilu oraz preferencji powiadomień,
- eksport i import kopii danych w formacie JSON,
- przywracanie danych demonstracyjnych,
- semantyczny HTML5, dostępne etykiety i obsługa klawiatury,
- rozbudowane widoki mobilne, tabletowe i desktopowe.

## Lokalna baza danych

Aplikacja korzysta z natywnej bazy **IndexedDB** przeglądarki. Warstwa dostępu znajduje się w:

```text
src/services/database.js
```

Baza `nexus-arena-local` zawiera magazyny:

- `tournaments`,
- `teams`,
- `players`,
- `matches`,
- `activities`,
- `announcements`,
- `settings`.

Operacje tworzenia, odczytu, aktualizacji i usuwania są wykonywane przez wydzielony serwis. Dzięki temu można później zastąpić IndexedDB wywołaniami REST, Supabase, Firebase albo własnym backendem bez przebudowy widoków.

> Dane są lokalne dla danej przeglądarki i domeny. Usunięcie danych witryny usuwa również bazę aplikacji.

## Struktura projektu

```text
src/
├── components/       # elementy wspólne, nawigacja i modale
├── context/          # stan aplikacji i operacje biznesowe
├── data/             # dane startowe
├── pages/            # wszystkie widoki aplikacji
├── services/         # warstwa IndexedDB
├── styles/           # arkusze CSS podzielone tematycznie
└── utils/            # formatowanie dat, walut i identyfikatorów
```

## Kontrola jakości

```bash
npm run lint
npm run build
```

Obie komendy powinny zakończyć się bez błędów.
